# Required Libraries
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer

from sqlalchemy import create_engine


user = "root"
pw = "anand"
db = "project2"
engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}")


sql = "select * from tender;"
df = pd.read_sql_query(sql, engine)


df.columns

df.sample(10)


df.isnull().sum()


# Data Cleaning
df.duplicated().sum()


df.drop_duplicates(keep='first', inplace = True)
df


df.info()


# Define features and target
features = ['Railway_Location', 'Nature', 'Basic', 'Qty']
target = 'L1_Price'

# Split the data into features (X) and target (y)
X = df[features]
y = df[target]

# Identify categorical and numerical features
categorical_features = ['Railway_Location', 'Nature']
numerical_features = ['Basic', 'Qty']



# Preprocessing for numerical features
numerical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),  # Handle missing values with median
    ('scaler', StandardScaler())  # Scale numerical values
])


# Preprocessing for categorical features
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),  # Handle missing values with a constant value
    ('onehot', OneHotEncoder(handle_unknown='ignore'))  # One-hot encode categorical values
])


# Bundle preprocessing for numerical and categorical features
preprocessor = ColumnTransformer(transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
])


# Example usage: fit_transform on X to get preprocessed features
X_preprocessed = pd.DataFrame(preprocessor.fit_transform(X).todense())

# X_preprocessed now contains the transformed features ready for modeling
print(X_preprocessed)
