# Required libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Auto EDA
import sweetviz as sv

from sqlalchemy import create_engine

user = "root"
pw = "anand"
db = "project2"
engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}")


sql = "select * from tender;"
df = pd.read_sql_query(sql, engine)



df.sample(10)



df.iloc[10]



df.info()


df.describe()


# droping columns which are not required
df.drop(['Tender_no', 'Zone', 'Division', 'DateofOpening', 'Customer_1', 'Customer_2', 'Customer_3','Customer_4','Customer_5','Customer_6','Customer_7','Customer_8','Customer_9','Customer_10','Customer_11','Customer_12'], axis = 1, inplace = True)
df.columns


# First moment Business descion
# Mean
print("L1_Price Mean:", df.L1_Price.mean())
print("Basic Mean:", df.Basic.mean())
print("Qty Mean:", df.Qty.mean())

# Second moment Business descion
# varience
print("L1_Price varience:", df.L1_Price.var())
print("Basic varience:", df.Basic.var())
print("Qty varience:", df.Qty.var())

# standerd deviation
print("L1_Price standerd deviation:", df.L1_Price.std())
print("Basic standerd deviation:", df.Basic.std())
print("Qty standerd deviation:", df.Qty.std())

# third moment business descion -skewness
print("L1_Price skewness:", df.L1_Price.skew())
print("Basic skewness:", df.Basic.skew())
print("Qty skewness:", df.Qty.skew())

# forth moment business descion - kurtosis
print("L1_Price kurtosis:", df.L1_Price.kurt())
print("Basic kurtosis:", df.Basic.kurt())
print("Qty kurtosis:", df.Qty.kurt())


# Initialize a dictionary to store the counts of unique items
unique_counts = {}

# For loop to count unique items in each column
for column in df.columns:
    unique_counts[column] = df[column].nunique()

# Display the result
unique_counts


#Top 15 Railway_Location According to majority
Railway_Loca_names = df.Railway_Location.value_counts().index
Railway_Loca_values = df.Railway_Location.value_counts().values
plt.figure(figsize = (8,8))
plt.pie(Railway_Loca_values[:15], labels = Railway_Loca_names[:15], autopct = "%1.2f%%", pctdistance = 1.10, labeldistance=0.8)


grouped_data = df.groupby(['Railway_Location', 'Nature', 'Category', 'Awarded_to']).size().reset_index().rename({'0' : 'No_of_records'})
grouped_data

plt.rcParams['figure.figsize'] = (10, 6)
sns.barplot(data = df, errorbar=("ci", 50))
plt.show()


sns.countplot(data = df, x = 'Category')


Awarded_to_names = df.Awarded_to.value_counts().index
Awarded_to_values = df.Awarded_to.value_counts().values
plt.figure(figsize=(6,6))
plt.pie(Awarded_to_values, labels = Awarded_to_names, autopct = "%1.2f%%", pctdistance = 1.20, labeldistance=1.35)


Nature_names = df.Nature.value_counts().index
Nature_values = df.Nature.value_counts().values
plt.pie(Nature_values, labels = Nature_names, autopct = "%1.2f%%")


df.isnull().sum()


# Auto EDA
report = sv.analyze(df)
report.show_html()


# Multivariate Analysis
sns.pairplot(df)   # original data


# Correlation Analysis on Original Data
orig_df_cor = df.corr(method='pearson')
orig_df_cor


# Heatmap
dataplot = sns.heatmap(orig_df_cor, annot=True, cmap="YlGnBu")


# Heatmap enhanced
# Generate a mask to show values on only the bottom triangle
# Upper triangle of an array.
mask = np.triu(np.ones_like(orig_df_cor, dtype=bool))
sns.heatmap(orig_df_cor, annot=True, mask=mask, vmin=-1, vmax=1)
plt.title('Correlation Coefficient Of Predictors')
plt.show()
