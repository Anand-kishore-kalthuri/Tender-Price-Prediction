#importing necessory libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_percentage_error
import numpy as np
from sqlalchemy import create_engine


# Load the dataset
user = "root"
pw = "anand"
db = "project2"
engine = create_engine(f"mysql+pymysql://{user}:{pw}@localhost/{db}")

sql = "select * from tender;"
df = pd.read_sql_query(sql, engine)
df


# Define features and target
features = ['Railway_Location', 'Nature', 'Basic', 'Qty', 'Category']
target = 'L1_Price'

X = df[features]
y = df[target]

# Identify categorical and numerical features
categorical_features = ['Railway_Location', 'Nature', 'Category']
numerical_features = ['Basic', 'Qty']

# Preprocessing for numerical features
numerical_transformer = Pipeline(steps=[
    ('scaler', StandardScaler())
])

# Preprocessing for categorical features
categorical_transformer = Pipeline(steps=[
    ('onehot', OneHotEncoder(handle_unknown='ignore'))
])

# Bundle preprocessing for numerical and categorical features
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numerical_transformer, numerical_features),
        ('cat', categorical_transformer, categorical_features)
    ])

# Define models to evaluate
models = {
    'Linear Regression': LinearRegression(),
    'Ridge Regression': Ridge(alpha=0.1),
    'Decision Tree': DecisionTreeRegressor(random_state=0),
    'Random Forest': RandomForestRegressor(random_state=0),
    'Gradient Boosting': GradientBoostingRegressor(random_state=0),
    'XGBoost': XGBRegressor(random_state=0),
    'Support Vector Regressor': SVR()
}


# Split data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Evaluate each model
for name, model in models.items():
    # Create a pipeline that includes preprocessing and the model
    pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', model)
    ])
    
    # Fit the model on the training data
    pipeline.fit(X_train, y_train)
    
    # Predict on the training data
    y_train_pred = pipeline.predict(X_train)
    
    # Predict on the test data
    y_test_pred = pipeline.predict(X_test)
    
    # Evaluate the model
    train_mse = mean_squared_error(y_train, y_train_pred)
    test_mse = mean_squared_error(y_test, y_test_pred)
    
    train_rmse = np.sqrt(train_mse)
    test_rmse = np.sqrt(test_mse)
    
    train_mape = mean_absolute_percentage_error(y_train, y_train_pred)
    test_mape = mean_absolute_percentage_error(y_test, y_test_pred)
    
    train_r2 = r2_score(y_train, y_train_pred)
    test_r2 = r2_score(y_test, y_test_pred)
    
    # Print evaluation metrics
    print(f"{name} Model")
    print(f"Training Mean Squared Error: {train_mse}")
    print(f"Testing Mean Squared Error: {test_mse}")
    print(f"Training RMSE: {train_rmse}")
    print(f"Testing RMSE: {test_rmse}")
    print(f"Training MAPE: {train_mape}")
    print(f"Testing MAPE: {test_mape}")
    print(f"Training R^2 Score: {train_r2}")
    print(f"Testing R^2 Score: {test_r2}")
    print("-" * 50)


pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', Ridge(alpha=0.1))
    ])
import pickle
# Save the Ridge regression model as a pickle file
with open('XGBoost Model.pkl', 'wb') as file:
    pickle.dump(pipeline, file)
    
print("XGBoost Model saved successfully.")

# Define Linear regression model
linear_model = LinearRegression()

# Create pipeline including preprocessing and model
pipeline_linear = Pipeline(steps=[
    ('preprocessor', preprocessor),
    ('regressor', linear_model)
])

# Fit the model on the training data
pipeline_linear.fit(X_train, y_train)

# Save the Linear regression model as a pickle file
with open('linear_regression_model.pkl', 'wb') as file:
    pickle.dump(pipeline_linear, file)
    
print("Linear regression model saved successfully.")
