import streamlit as st
import pandas as pd
import pickle

# Load the Linear regression model from pickle file
with open('linear_regression_model.pkl', 'rb') as file:
    linear_model = pickle.load(file)

# Function to make predictions and calculate evaluation metrics
def predict_and_evaluate(model, data):
    # Prepare input data as DataFrame
    input_data = pd.DataFrame(data, index=[0])
    
    # Make predictions
    prediction = model.predict(input_data)
    
    return prediction[0]  # Return the predicted value

# Streamlit app layout
def main():
    st.title('Railway Tender Price Prediction')
    st.write('This application predicts L1 Price based on input features using Linear Regression.')

    # Input form for user to input data
    st.header('Input Features')

    # User inputs with placeholders
    railway_location = st.selectbox('Select Railway Location', ['Select Railway Location', 'BHOPAL', 'JABALPUR', 'NAGPUR', 'TRICHCHIRAPPALLI', 'MUMBAI',
                                                               'CHENNAI', 'KHURDA', 'MYSORE', 'KHARAGPUR', 'HUBLI',
                                                               'WALTAIR', 'MUGHALSARAI', 'HOWRAH', 'DANAPUR', 'KOTA',
                                                               'LUMDING', 'LUCKNOW', 'AGRA', 'ALIPURDUAR', 'GCustomer_5KHPUR',
                                                               'MALDA', 'SONPUR', 'AHMEDABAD', 'RAIPUR', 'RATLAM', 'SEALDAH',
                                                               'PRAYAGRAJ', 'JHANSI', 'SECUNDRABAD', 'SAMBALPUR', 'RANGIYA',
                                                               'VARANASI', 'FEROZPUR', 'PALAKKAD', 'KATIHAR', 'TINSUKIA',
                                                               'VADODARA', 'DHANBAD', 'BHUSAWAL', 'DELHI', 'BIKANER', 'BHAVNAGAR'])

    nature = st.selectbox('Select Nature', ['Select Nature', 'Supply', 'Execution', 'Supervision', 'equipment'])
    category = st.selectbox('Select Category', ['Select Category', '52 Kg', '60 Kg', '60/52 CMD', 'HH 1080', 'R260', 'R260 CMD'])
    basic = st.number_input('Enter Basic', value=0)
    qty = st.number_input('Enter Qty', value=0)
    
    # Gather user input
    user_input = {
        'Railway_Location': railway_location,
        'Nature': nature,
        'Basic': basic,
        'Category': category,
        'Qty': qty
    }

    # Ensure the user selects valid options
    if railway_location == 'Select Railway Location':
        st.warning("Please select a valid Railway Location.")
    elif nature == 'Select Nature':
        st.warning("Please select a valid Nature.")
    elif category == 'Select Category':
        st.warning("Please select a valid Category.")
    else:
        # Predictions and evaluation for Linear Regression
        if st.button('Predict Price - Linear Regression Model'):
            predicted_price = predict_and_evaluate(linear_model, user_input)
            st.success(f'Predicted Price (Linear Regression): {predicted_price:.2f}')

if __name__ == '__main__':
    main()
